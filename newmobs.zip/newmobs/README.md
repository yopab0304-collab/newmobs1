# New Mobs (Fabric, Minecraft 26.3)

ม็อดเพิ่มมอนสเตอร์และสัตว์ใหม่ 2 ตัว

| มอน | ชนิด | รายละเอียด |
|---|---|---|
| **Stone Brute** | มอนสเตอร์ | เลือด 40, ตี 6, เกราะ 4, กันแรงสะเทือน 60% ไล่ล่าผู้เล่น เกิดในโอเวอร์เวิลด์ตอนมืด (หายาก) ดรอปหินกลม + เหล็กแท่งบางครั้ง |
| **Moss Hopper** | สัตว์เชื่อง | เลือด 8 ตกใจง่าย ถือแครอทล่อให้เดินตามได้ เกิดในป่าและป่าดิบชื้น ดรอปบล็อกตะไคร่ (50%) |

มีไข่เสก (Spawn Egg) ของทั้งสองตัวในแท็บ Spawn Eggs ของ Creative หรือใช้คำสั่ง
`/summon newmobs:stone_brute` และ `/summon newmobs:moss_hopper`

## ต้องมีอะไร

- JDK **25** (Minecraft 26.x ใช้ Java 25)
- Gradle 9.5+ (หรือใช้ wrapper)

## วิธีเริ่มต้น

โฟลเดอร์นี้ไม่มีไฟล์ `gradlew` / `gradle-wrapper.jar` (เป็นไฟล์ไบนารี) สร้างได้สองวิธี:

1. ติดตั้ง Gradle แล้วรันในโฟลเดอร์นี้: `gradle wrapper --gradle-version 9.5.1`
2. หรือคัดลอก `gradlew`, `gradlew.bat` และ `gradle/wrapper/gradle-wrapper.jar` มาจาก
   https://github.com/FabricMC/fabric-example-mod

จากนั้น:

```
./gradlew runClient     # เปิดเกมทดสอบ
./gradlew build         # สร้างไฟล์ .jar ที่ build/libs/newmobs-1.0.0.jar
```

นำไฟล์ `.jar` (ไม่ใช่ `-sources.jar`) ไปวางในโฟลเดอร์ `mods` พร้อม Fabric Loader 0.19.5+ และ Fabric API 0.164.0+26.3

## ถ้า build ไม่ผ่าน

ตรวจเวอร์ชันล่าสุดที่ https://fabricmc.net/develop แล้วแก้ใน `gradle.properties`
(โดยเฉพาะ `loom_version`) ส่วนชื่อคลาส/เมธอดของ Minecraft 26.x อาจเปลี่ยนเล็กน้อยระหว่างเวอร์ชัน
ดูคู่มือที่ https://docs.fabricmc.net/develop/porting/

## โครงสร้าง

```
src/main/java/com/example/newmobs/
  NewMobs.java               จุดเริ่มต้น + กำหนดที่เกิดตามไบโอม
  entity/StoneBruteEntity    พฤติกรรม/ค่าพลังของมอนสเตอร์
  entity/MossHopperEntity    พฤติกรรม/ค่าพลังของสัตว์
  registry/ModEntityTypes    ลงทะเบียนเอนทิตี + กติกาการเกิด
  registry/ModItems          ไข่เสก + แท็บ Creative
src/client/java/.../client/
  model/                     โมเดล 3D (กล่องต่อกัน)
  renderer/                  ผูกโมเดล + texture
  state/                     render state
src/main/resources/
  assets/newmobs/            ภาษา, texture, โมเดลไอเทม
  data/newmobs/loot_table/   ของที่ดรอป
```

## ปรับแต่งง่าย ๆ

- **ค่าพลัง**: แก้ `createAttributes()` ในไฟล์ entity
- **ความถี่ที่เกิด**: แก้เลขน้ำหนักใน `NewMobs.registerNaturalSpawns()`
- **ขนาดตัว**: แก้ `.sized(กว้าง, สูง)` ใน `ModEntityTypes`
- **หน้าตา**: แก้ PNG ใน `textures/entity/` (Brute 64x64, Hopper 64x32) ด้วยโปรแกรมวาดรูปหรือ Blockbench
- **พฤติกรรม**: แก้ `registerGoals()` เลข priority น้อย = สำคัญกว่า
